/*
MySQL Data Transfer
Source Host: localhost
Source Database: ry-new1
Target Host: localhost
Target Database: ry-new1
Date: 2025/11/10 20:42:46
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for issues
-- ----------------------------
DROP TABLE IF EXISTS `issues`;
CREATE TABLE `issues` (
  `issue_id` int NOT NULL AUTO_INCREMENT COMMENT '问题id',
  `project_id` int DEFAULT NULL COMMENT '问题所属项目id',
  `task_id` int DEFAULT NULL COMMENT '问题所属任务',
  `issue_type` varchar(20) DEFAULT NULL COMMENT '问题类型',
  `description` text COMMENT '问题描述',
  `status` varchar(20) DEFAULT NULL COMMENT '问题状态',
  `created_by` int DEFAULT NULL COMMENT '创建者id',
  `created_at` datetime DEFAULT NULL COMMENT '问题创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '问题更新时间',
  PRIMARY KEY (`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for operation_logs
-- ----------------------------
DROP TABLE IF EXISTS `operation_logs`;
CREATE TABLE `operation_logs` (
  `log_id` int NOT NULL AUTO_INCREMENT COMMENT '操作日志id',
  `user_id` int DEFAULT NULL COMMENT '操作用户id',
  `operation_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作类型',
  `operation_detail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '操作详细描述',
  `operation_time` datetime DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for progress_reports
-- ----------------------------
DROP TABLE IF EXISTS `progress_reports`;
CREATE TABLE `progress_reports` (
  `report_id` int NOT NULL AUTO_INCREMENT COMMENT '进度报告id',
  `project_id` int DEFAULT NULL COMMENT '项目id',
  `report_date` date DEFAULT NULL COMMENT '报告日期',
  `progress` decimal(5,2) unsigned zerofill DEFAULT NULL COMMENT '项目进度',
  `expected_end_date` date DEFAULT NULL COMMENT '预期完成日期',
  `actual_end_date` date DEFAULT NULL COMMENT '实际完成日期',
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for project_members
-- ----------------------------
DROP TABLE IF EXISTS `project_members`;
CREATE TABLE `project_members` (
  `member_id` int NOT NULL AUTO_INCREMENT COMMENT '成员id',
  `project_id` int DEFAULT NULL COMMENT '项目id',
  `user_id` int DEFAULT NULL COMMENT '用户id',
  `role` varchar(50) DEFAULT NULL COMMENT '用户角色',
  `joined_at` datetime DEFAULT NULL COMMENT '用户加入项目时间',
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for projects
-- ----------------------------
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `project_id` int NOT NULL AUTO_INCREMENT COMMENT '项目id',
  `project_name` varchar(100) DEFAULT NULL COMMENT '项目名称',
  `description` text COMMENT '项目描述',
  `start_date` date DEFAULT NULL COMMENT '项目开始日期',
  `end_date` date DEFAULT NULL COMMENT '项目预计结束日期',
  `created_by` int DEFAULT NULL COMMENT '创建者id',
  `created_at` datetime DEFAULT NULL COMMENT '项目创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '项目更新时间',
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for role_permissions
-- ----------------------------
DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `role_id` int NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `role_name` varchar(50) DEFAULT NULL COMMENT '角色名称',
  `permission` varchar(100) DEFAULT NULL COMMENT '角色权限',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for system_administrators
-- ----------------------------
DROP TABLE IF EXISTS `system_administrators`;
CREATE TABLE `system_administrators` (
  `admin_id` int NOT NULL AUTO_INCREMENT COMMENT '管理员id',
  `user_id` int NOT NULL COMMENT '用户id',
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for task_members
-- ----------------------------
DROP TABLE IF EXISTS `task_members`;
CREATE TABLE `task_members` (
  `task_member_id` int NOT NULL AUTO_INCREMENT COMMENT '任务成员id',
  `task_id` int DEFAULT NULL COMMENT '任务id',
  `user_id` int DEFAULT NULL COMMENT '用户id',
  `assigned_at` datetime DEFAULT NULL COMMENT '任务分配给成员的时间',
  PRIMARY KEY (`task_member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for tasks
-- ----------------------------
DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `task_id` int NOT NULL AUTO_INCREMENT COMMENT '任务id',
  `project_id` int DEFAULT NULL COMMENT '项目id',
  `task_name` varchar(100) DEFAULT NULL COMMENT '任务名称',
  `description` text COMMENT '任务描述',
  `priority` varchar(20) DEFAULT NULL COMMENT '任务优先级',
  `status` varchar(20) DEFAULT NULL COMMENT '任务状态',
  `created_by` int DEFAULT NULL COMMENT '创建者用户id',
  `assigned_to` int DEFAULT NULL COMMENT '任务分配给用户id',
  `created_at` datetime DEFAULT NULL COMMENT '任务创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '任务更新时间',
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for user_roles
-- ----------------------------
DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE `user_roles` (
  `user_role_id` int NOT NULL AUTO_INCREMENT COMMENT '用户角色id',
  `user_id` int DEFAULT NULL COMMENT '用户id',
  `role_id` int DEFAULT NULL COMMENT '角色id',
  PRIMARY KEY (`user_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `password_hash` varchar(255) DEFAULT NULL COMMENT '加密后的密码',
  `email` varchar(100) DEFAULT NULL COMMENT '用户邮箱',
  `role` varchar(50) DEFAULT NULL COMMENT '用户角色',
  `created_at` datetime DEFAULT NULL COMMENT '账号创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '账号更新时间',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for workloads
-- ----------------------------
DROP TABLE IF EXISTS `workloads`;
CREATE TABLE `workloads` (
  `report_id` int NOT NULL AUTO_INCREMENT COMMENT '进度报告id',
  `project_id` int DEFAULT NULL COMMENT '项目id',
  `report_date` date DEFAULT NULL COMMENT '报告日期',
  `progress` decimal(5,2) unsigned zerofill DEFAULT NULL COMMENT '项目进度',
  `expected_end_date` date DEFAULT NULL COMMENT '预期完成日期',
  `actual_end_date` date DEFAULT NULL COMMENT '实际完成日期',
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records 
-- ----------------------------
