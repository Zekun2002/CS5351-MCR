/*
MySQL Data Transfer
Source Host: localhost
Source Database: ry-new1
Target Host: localhost
Target Database: ry-new1
Date: 2025/11/10 20:41:54
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `password_hash` varchar(255) DEFAULT NULL COMMENT '加密后的密码',
  `email` varchar(100) DEFAULT NULL COMMENT '用户邮箱',
  `role` varchar(50) DEFAULT NULL COMMENT '用户角色',
  `created_at` datetime DEFAULT NULL COMMENT '账号创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '账号更新时间',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records 
-- ----------------------------
